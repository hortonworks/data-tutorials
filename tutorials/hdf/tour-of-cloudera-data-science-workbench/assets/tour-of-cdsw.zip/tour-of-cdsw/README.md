A tour of Cloudera Data Science Workbench (CDSW)

## Workbench

1. **Basic Python visualizations.** Demonstrates:
  - Markdown via comments
  - Jupyter-compatible visualizations
  - Simple console sharing

## Setup instructions

>Note: You only need to do this once.

### Run the following

```Python
!pip3 install --upgrade matplotlib
!pip3 install --upgrade pandas_highcharts
!pip3 install --upgrade protobuf
!pip3 install --upgrade seaborn
!pip3 install --upgrade sklearn
```
